// Function to check if a given URL matches the LinkedIn profile URL format
function isValidLinkedInURL(url) {
    // Regular expression to match valid LinkedIn profile URLs
    const linkedInRegex = /^https:\/\/www\.linkedin\.com\/in\/[a-zA-Z0-9_-]{5,30}[a-zA-Z0-9]$/;
  
    // Test the URL against the regex
    return linkedInRegex.test(url);
  }
  
  // Test LinkedIn profile URLs
  const urlsToTest = [
    "https://www.linkedin.com/in/johndoe123",
    "https://www.linkedin.com/in/john_doe",
    "https://www.linkedin.com/in/johndoe-",
    "https://www.linkedin.com/in/johndoe_",
    "https://www.linkedin.com/in/johndoe",
    "https://www.linkedin.com/in/johndoe1234567890123456789012345678901", // Too long
    "https://www.linkedin.com/in/johndoe@username", // Contains invalid character
    "https://www.linkedin.com/johndoe" // Does not match the format
  ];
  
  // Check each URL and print the result
  urlsToTest.forEach(url => {
    if (isValidLinkedInURL(url)) {
      console.log(url + " is a valid LinkedIn profile URL.");
    } else {
      console.log(url + " is not a valid LinkedIn profile URL.");
    }
  });
  
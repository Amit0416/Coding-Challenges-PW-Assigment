// Input list of books with authors and publication years
const books = [
    { title: "Book1", author: "author1", publicationYear: 2005 },
    { title: "Book2", author: "author2", publicationYear: 2012 },
    { title: "Book3", author: "author3", publicationYear: 2008 },
    // Add more books as needed
  ];
  
  // Function to filter out books published before 2010 and capitalize author names
  function filterAndCapitalize(books) {
    return books
      .filter(book => book.publicationYear >= 2010) // Filter out books published before 2010
      .map(book => {
        return {
          title: book.title,
          author: book.author.toUpperCase(), // Capitalize author names
          publicationYear: book.publicationYear
        };
      });
  }
  
  // Call the function with the list of books
  const filteredBooks = filterAndCapitalize(books);
  
  // Display the filtered books
  console.log(filteredBooks);
  
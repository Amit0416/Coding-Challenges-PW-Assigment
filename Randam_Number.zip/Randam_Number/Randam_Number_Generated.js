// Function to generate a random number
function generateRandomNumber() {
    return Math.floor(Math.random() * 100); // Generates a random number between 0 and 99
  }
  
  // Function to display the remaining time until the random number is generated
  function displayTimeRemaining(timeRemaining) {
    console.log("Time remaining: " + timeRemaining + " seconds");
  }
  
  // Function to generate a random number after a specified delay
  function generateNumberAfterDelay(delay) {
    setTimeout(function() {
      let randomNumber = generateRandomNumber();
      console.log("Generated random number: " + randomNumber);
    }, delay * 1000);
  }
  
  // Function to display the countdown and generate the random number after a delay
  function countdownAndGenerateRandomNumber(delay) {
    let timeRemaining = delay;
    const countdownInterval = setInterval(function() {
      displayTimeRemaining(timeRemaining);
      timeRemaining--;
  
      if (timeRemaining < 0) {
        clearInterval(countdownInterval);
        generateNumberAfterDelay(delay);
      }
    }, 1000);
  }
  
  // Define the delay
  let delay = 3; // 3 seconds delay
  
  // Call the function with the specified delay
  countdownAndGenerateRandomNumber(delay);
  
// Function to check if a given URL matches the conditions
function isValidURL(url) {
    // Regular expression to match valid URLs
    const urlRegex = /^(http:\/\/|https:\/\/)[a-zA-Z0-9-_]+(\.[a-zA-Z]+)+$/;
  
    // Test the URL against the regex
    return urlRegex.test(url);
  }
  
  // Test URLs
  const urlsToTest = [
    "https://www.hackerrank.com/profile/ami_tkumar_84",
    "https://github.com/Amit0416",
    "https://www.javatpoint.com/",
  ];
  
  // Check each URL and print the result
  urlsToTest.forEach(url => {
    if (isValidURL(url)) {
      console.log(url + " is a valid URL.");
    } else {
      console.log(url + " is not a valid URL.");
    }
  });
  
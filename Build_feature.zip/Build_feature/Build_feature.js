// Original object containing items and their prices in USD
const pricesInUSD = {
    "item1": 20,
    "item2": 35,
    "item3": 10,
    // Add more items and prices as needed
  };
  
  // Function to convert USD prices to INR
  function convertToINR(priceUSD) {
    const exchangeRate = 80; // 1 USD = 80 INR
    return priceUSD * exchangeRate;
  }
  
  // Use map to create a new object with prices converted to INR
  const pricesInINR = Object.fromEntries(
    Object.entries(pricesInUSD).map(([item, priceUSD]) => [item, convertToINR(priceUSD)])
  );
  
  // Display the converted prices
  console.log("Prices in INR:", pricesInINR);
  
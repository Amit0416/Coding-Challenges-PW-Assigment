// Define the input string
let input = "Hello, world!";

// Function to reverse the string
function reverseString(str) {
  return str.split("").reverse().join("");
}

// Function to reverse the string after a delay of 2 seconds
function reverseAfterDelay(inputString) {
  setTimeout(function() {
    let reversedString = reverseString(inputString);
    console.log(reversedString);
  }, 2000);
}

// Call the function with the input string
reverseAfterDelay(input);
